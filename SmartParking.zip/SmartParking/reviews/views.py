from reviews.forms import ReviewForm
from django.shortcuts import render
from django.http import HttpResponse, response
import csv
from .models import BookReviewModel
# Create your views here.
def BookReviewView(request):
 
    if request.method == 'POST':
        form = ReviewForm(request.POST)
        if form.is_valid():
            form.save()
            return HttpResponse('Your review has been taken')
 
    else:
        form = ReviewForm()
        context = {
            'form':form,
        }
    return render(request, 'index.html', context)

def export(request):
    response = HttpResponse(content_type='text/csv')
    
    
    writer = csv.writer(response)
    writer.writerow(['Name','Review'])
    
    for BookReviewModels in BookReviewModel.objects.all().values_list('name', 'review'):
        writer.writerow(BookReviewModels)
    
    response['Content-Disposition'] = 'attachemnt ; filename = "BookReviewModel.csv"'
    return response
    