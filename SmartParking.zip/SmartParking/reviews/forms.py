from django import forms
from .models import BookReviewModel

class ReviewForm(forms.ModelForm):
    class Meta:
        model = BookReviewModel
        fields =('name','review',)